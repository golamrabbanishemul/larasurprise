<?php $__env->startSection('main_content'); ?>
    <div class="card mt-3">
        <div class="card-header"><h2>Edit Post</h2></div>
        <div class="card-body">

            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="col-sm-12">
                <?php echo Form::model($post,['route'=>['posts.update',$post->id],'method'=>'PUT','files'=>true]); ?>

                <div class="form-group">
                    <?php echo e(Form::label('title','Title')); ?>

                    <?php echo e(Form::text('title',null,['class'=>'form-control'])); ?>

                </div>
            </div>

            <div class="col-sm-12">
                <div class="form-group">
                    <?php echo e(Form::label('description','Post Description')); ?>

                    <?php echo e(Form::textarea('description', null, ['class'=>'form-control'])); ?>

                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="category_id">Select Category</label>
                    <select name="category_id" id="category_id" class="form-control">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->id == $post->category_id): ?>
                                <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <?php echo e(Form::label('home','Show Home Page')); ?>

                    <?php echo e(Form::checkbox('home',null, ['class'=>'checkbox-inline'])); ?>

                </div>
            </div>

            <div class="col-sm-6">
                <div class="form-group">
                    <?php echo e(Form::label('image','Current Image')); ?><br>
                    <img src="<?php echo e(asset('images/'.$post->image)); ?>" alt="image" width="80" height="80">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <?php echo e(Form::label('image','Post Image')); ?>

                    <?php echo e(Form::file('image', ['class' => 'form-control'])); ?>

                </div>
            </div>


            <div class="col-sm-12">
                <div class="form-group">
                    <select name="publication_status"
                            class="form-control">
                        <?php if($post->publication_status > 0 ): ?>
                            <option selected value="<?php echo e($post->publication_status); ?>">Publish</option>
                        <?php endif; ?>
                        <option value="0">Un Publish</option>
                        <option value="1">Publish</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    <button type="reset" class="btn btn-default">Cancel</button>
                </div>
            </div> <?php echo Form::close(); ?></div>
    </div><!--/row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>