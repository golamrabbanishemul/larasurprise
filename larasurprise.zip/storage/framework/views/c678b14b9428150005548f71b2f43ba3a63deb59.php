<?php $__env->startSection('title','Edit Category'); ?>
<?php $__env->startSection('main_content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-10">
                <div class="card mt-3">
                    <div class="card-header">
                        EDIT CATEGORY
                    </div>
                    <div class="card-body">
                        <?php if(Session::get('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show success_msg" role="alert">
                                <h4><?php echo e(Session::get('message')); ?></h4>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if(count($errors)>0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php echo Form::model($category,['route'=>['category.update',$category->id],'method'=>'PUT', 'files'=>true]); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('name','Edit Category Name')); ?>

                            <?php echo e(Form::text('name',null,['class'=>'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="parent_cat">Parent Category</label><br>
                            <select name="parent_cat" id="parent_cat" class="form-control">
                                <option value="0">Parent Category</option>
                                <?php $__currentLoopData = $allcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($catrec['id']); ?>" <?php echo e($category['parent_category']==$catrec['id']? 'selected':''); ?>>
                                        <?php echo e($catrec['name']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('description','Description')); ?>

                            <?php echo e(Form::textarea('description',null,['class'=>'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <label for="">Current Image</label><br>
                            <img src="<?php echo e(asset('images/'.$category->image)); ?>" width="80" height="80" alt="">
                        </div>
                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <?php echo e(Form::label('image','Banner Image')); ?>

                                    <?php echo e(Form::file('image',['class'=>'form-control'])); ?>

                                </div>
                            </div>
                            <div class="col-sm">
                                <label for="position">Select Position</label>
                                <select name="position" id="position" class="form-control">
                                    <?php for($i=1; $i<=8; $i++): ?>
                                        <?php if($category['position'] == $i): ?>

                                    <option value="<?php echo e($i); ?>" selected>Position-<?php echo e($i); ?></option>
                                   <?php endif; ?>
                                    <option value="<?php echo e($i); ?>">Position-<?php echo e($i); ?></option>
                                        <?php endfor; ?>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('publication_status','Publication Status')); ?>

                            <br>
                            <?php echo e(Form::select('publication_status',['Un Published','Published'],null,['class'=>'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::submit('Update',['class'=>'btn btn-info'])); ?>

                            <?php echo e(Html::linkRoute('category.index','Cancel',[],['class'=>'btn btn-danger'])); ?>

                        </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>