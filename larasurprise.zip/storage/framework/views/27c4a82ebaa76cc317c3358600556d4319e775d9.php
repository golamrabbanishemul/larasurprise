<?php $__env->startSection('main_content'); ?>
    <h3 class="text-center mt-5 pt-5">Welcome <br> To Surprise Communication Dashboard</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>