<?php $__env->startSection('title','All Categories'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="card mt-3">
        <div class="card-header">
            <div class="d-inline pr-4">ALL CATEGORIES</div>
            <div class="d-inline"><a href="<?php echo e(route('category.create')); ?>" class="btn btn-outline-primary btn-sm"> Add New
                    +</a></div>
        </div>

        <?php if(Session::get('message')): ?>
            <div class="alert alert-success alert-dismissible fade show success_msg" role="alert">
                <h4><?php echo e(Session::get('message')); ?></h4>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <table class="table table-bordered  mt-1">
                <thead class="bg-light">
                <tr>

                    <th scope="col">CATEGORY</th>
                    <th scope="col">IMAGE</th>
                    <th scope="col">STATUS</th>
                    <th scope="col">ACTION</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <?php if(!empty($category->image)): ?>
                                <img width="100" height="60" src="<?php echo e(asset('images/'.$category->image)); ?>" alt="image">
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($category->publication_status==1): ?>
                                <a class="btn btn-success" href="<?php echo e(asset('unpublished-category/'.$category->id)); ?>"
                                   style="float: left;margin-right: 3px;">
                                    <i class="far fa-thumbs-down"></i>
                                </a>
                            <?php else: ?>
                                <a class="btn btn-danger" href="<?php echo e(asset('published-category/'.$category->id)); ?>"
                                   style="float: left;margin-right: 3px;">
                                    <i class="far fa-thumbs-up"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo Html::decode(Html::linkRoute('category.edit','<i class="far fa-edit"></i>', [$category->id],['class'=>'btn btn-info','style'=>'float:left; margin-right:5px'])); ?>

                            <?php echo Form::open(['route'=>['category.destroy',$category->id],'method'=>'DELETE']); ?>

                            <?php echo e(Form::button( '<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger','onclick'=>'return confirm("Are You Sure You Want To Delete This! ")'])); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>