<?php $__env->startSection('main_content'); ?>
    <div class="col-sm-10">
        <div class="card mt-3">
            <div class="card-header">
                <div class="d-inline pr-4">CREATE GALLERY</div>
            </div>
            <div class="card-body">
                <?php if(Session::get('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show success_msg" role="alert">
                        <h4><?php echo e(Session::get('message')); ?></h4>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php echo Form::open(['route'=>['galleries.store'],'files'=>true]); ?>

                <div class="form-group">
                    <label for="title">Title </label>
                    <input type="text" id="title" name="title" class="form-control">
                </div>

                <div class="form-group">
                    <?php echo e(Form::label('image','Add Post Banner Image')); ?>

                    <?php echo e(Form::file('image',['class'=>'form-control'])); ?>

                </div>

                <div class="form-group">
                    <select name="publication_status" class="form-control">
                        <option value="1">Published</option>
                        <option value="0">Un Published</option>
                    </select>
                </div>
                <?php echo e(Form::submit('Create New Gallery',['class'=>'btn btn-success btn-block'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>