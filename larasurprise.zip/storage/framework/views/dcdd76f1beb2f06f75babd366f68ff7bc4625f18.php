<?php $__env->startSection('main_content'); ?>
    <h3 class="text-center mt-5 pt-5">Welcome To Surprise Communication</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main_content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>