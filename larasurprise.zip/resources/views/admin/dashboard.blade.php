@extends('admin.admin_master')
@section('main_content')
    <h3 class="text-center mt-5 pt-5">Welcome <br> To Surprise Communication Dashboard</h3>

@endsection